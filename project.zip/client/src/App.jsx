import './App.css'
import Fib from './fib'

function App() {

  return (
    <>
     <Fib />
    </>
  )
}

export default App
